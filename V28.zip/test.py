import socket
import time

# Тестовый клиент с правильным протоколом
s = socket.socket()
s.connect(('192.168.0.109', 9339))

# Отправляем валидный пакет (packet_id=1, длина=0)
packet_id = 1  # какой-то ID пакета
length = 0
header = packet_id.to_bytes(2, 'big') + length.to_bytes(3, 'big') + b'\x00' * 2
s.send(header)

print("Пакет отправлен!")
time.sleep(0.5)
s.close()
print("Подключение закрыто")